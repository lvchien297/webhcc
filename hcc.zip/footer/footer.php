<div class="footer">
                <div class="footer-left">
                            <h2 class="footer-left-title">Liên hệ với chúng tôi </h2>
                            <div class="footer-left_icon">
                          <a href="https://www.facebook.com/Thinking-Ok-242217977734004" class="footer-icon"><i id="footer-fb" class="fa fa-facebook-official" aria-hidden="true"></i></a>  
                         <a href="" class="footer-icon"> <i id="footer-insta" class="fa fa-instagram" aria-hidden="true"></i></a>  
                          

                            </div>

                </div>
                <div class="footer-right">
                    <h2 class="footer-right_title">*Cửa hàng máy tính <span>HCC</span>  <br><br> Địa chỉ:  Chân Lý,Lý Nhân ,Hà Nam <br> <br>SĐT: 0964045230</h2>
                </div>
            </div>