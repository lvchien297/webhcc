function showpay()
{
    var number=$('#number').val();
    if(number<1){
        alert("Bạn chưa nhập số lượng");
        return false;
    }
   
}